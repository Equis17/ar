import Post from './Post'

export default () => {

    return <div className="col-md-8 col-lg-9 vstack gap-4">
        <Post></Post>
    </div>
}
