module.exports = {
  schema: [
    'userId',
    'articleId',
  ],
}
