module.exports = {
  schema: [
    'fromUserId',
    'toUserId',
  ],
}
