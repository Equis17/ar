/*
module.exports=(arr,pick)=>{
  return arr.filter(item=>pick.inc)
}*/
