module.exports = {
  db: {
    host: 'database-1.ccvym6aw4353.us-east-1.rds.amazonaws.com',
    user: 'admin',
    password: 'asdfASDF',
    database: 'blog',
  },
  token: {
    secretKey: 'A%&(SD)(AS*DAV^AD%*^VA%)(D^',
  },
}
