module.exports = {
  schema: [
    'name',
    'sort',
  ],
}
