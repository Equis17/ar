module.exports = {
  schema: [
    'email',
    'password',
    'gender',
    'avatarUrl',
    'description',
  ],
}
