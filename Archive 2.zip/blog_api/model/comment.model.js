module.exports = {
  schema: [
    'userId',
    'articleId',
    'content',
  ],
}
