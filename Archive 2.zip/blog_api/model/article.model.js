module.exports = {
  schema: [
    'title',
    'thumbnailUrl',
    'content',
    'userId',
    'categoryId',
    'isPublish'
  ],
}
